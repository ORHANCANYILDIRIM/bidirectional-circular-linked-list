package bagliliste;


import bagliliste.dugum;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MU$TA ORHAN
 */
public class baglicift {
    
    private dugum ilk = null;
    public void basaekle(int sayi)
    {
        dugum dugumyeni=new dugum(sayi);
        if(ilk==null){              //listede eleman var mı kontrol ediyor
            ilk=dugumyeni;
            ilk.önceki=ilk;              
            ilk.sonraki=ilk;
                
            return;           
        }
        dugumyeni.önceki=ilk.önceki;      // düğümleri birbirine bağlıyor
        dugumyeni.sonraki=ilk;
        ilk.önceki.sonraki=dugumyeni;
        ilk.önceki=dugumyeni;
        ilk=dugumyeni;    
    }
    public void sonaekle(int sayi)
    {
        dugum dugumyeni=new dugum(sayi);
        if(ilk==null){
            ilk=dugumyeni;
            ilk.önceki=ilk;              
            ilk.sonraki=ilk;
           
            return;           
        }

        ilk.önceki.sonraki=dugumyeni;
        dugumyeni.önceki=ilk.önceki;
        dugumyeni.sonraki=ilk;
        ilk.önceki=dugumyeni;
        
    }
    public boolean dugumdenonceekle(int sayi,int dugumdeger)
    {
        dugum dugumyeni=new dugum(sayi);
        dugum sonrakidugum=ilk;
        if(ilk==null)
            return false;
        
        while(sonrakidugum.sonraki!=ilk)
        {
            if(sonrakidugum.deger==dugumdeger)  
            {
                dugumyeni.sonraki=sonrakidugum;
                dugumyeni.önceki=sonrakidugum.önceki;
                sonrakidugum.önceki.sonraki=dugumyeni;
                sonrakidugum.önceki=dugumyeni;
                return true;              
            }    
            sonrakidugum=sonrakidugum.sonraki;
        }
        return false;
        
        
    }
    public boolean dugumdensonraekle(int sayi, int dugumdeger)
    {
        dugum dugumyeni=new dugum(sayi);
        dugum oncekidugum=ilk;
         if(ilk==null)
            return false;
         do{
             if(oncekidugum.deger==dugumdeger)  
            {
                
                dugumyeni.sonraki=oncekidugum.sonraki;
                dugumyeni.önceki=oncekidugum;
                oncekidugum.sonraki.önceki=dugumyeni;
                oncekidugum.sonraki=dugumyeni;
                
               
                
                return true;              
            }    
                oncekidugum=oncekidugum.sonraki;
         }
          while(oncekidugum!=ilk);
        
                        
        
        return false;
        

    }
    public boolean bastancikar()
    {
        if(ilk==null)
        {
            return false;
        }
            
        
        if(ilk.sonraki==ilk)
        {
            ilk=null;
            return true;
        }
        ilk.önceki.sonraki=ilk.sonraki;
        ilk.sonraki.önceki=ilk.önceki;
        ilk=ilk.sonraki;
        return true;
    }
    public boolean sondancikar()
    {
        if(ilk==null)
        {
            return false;
        }
         if(ilk.sonraki==ilk)    // tek elemanlı mı kontrol ediyor
        {
            ilk=null;
            return true;
        }
         ilk.önceki.önceki.sonraki=ilk;            
         ilk.önceki=ilk.önceki.önceki;
         return true;    
    }
    public boolean dugumdenoncecikar(int dugumdeger)
    {
        if(ilk==null)
        {
            return false;
        }
         if(ilk.sonraki==ilk)
        {
            return false ;
        }
         dugum gecici=ilk;
         do{
             if(gecici.sonraki.deger==dugumdeger){
                 if(gecici==ilk){
                      ilk.önceki.sonraki=ilk.sonraki;
                      ilk.sonraki.önceki=ilk.önceki;
                      ilk=ilk.sonraki;
                      return true;
                 }
                 gecici.önceki.sonraki=gecici.sonraki;
                 gecici.sonraki.önceki=gecici.önceki;
                 return true;
             }
             gecici=gecici.sonraki;
         }
         while(gecici!=ilk);
         return false;
    
    }
    public boolean dugumdensonracikar(int dugumdeger)
    {
         if(ilk==null)
        {
            return false;
        }
         if(ilk.sonraki==ilk)
        {
            return false ;
        }
         dugum gecici=ilk;
         do{
             if(gecici.deger==dugumdeger){
                 if(gecici.sonraki==ilk){
                      ilk.önceki.sonraki=ilk.sonraki;
                      ilk.sonraki.önceki=ilk.önceki;
                      ilk=ilk.sonraki;
                      return true;
                 }
                 gecici.sonraki.sonraki.önceki=gecici;
                 gecici.sonraki=gecici.sonraki.sonraki;
                 return true;
             }
             gecici=gecici.sonraki;
         }
         while(gecici!=ilk);
         return false;
    }
    public boolean arama(int dugumdeger)
    {
        dugum gecici=ilk;
        int sayac=1;
        if(ilk==null)
        {
            return false;
        }
        while(gecici.deger!=dugumdeger){
            gecici=gecici.sonraki;
            sayac++;
        }
        System.out.println("sayi"+sayac+".sirada bulundu");
        return true;
    }
    public boolean yazdir()
    {
       dugum yazdirdugum=ilk;
       if(ilk==null)
           return false;
           
       do
       {
           System.out.println(yazdirdugum.deger);
           yazdirdugum=yazdirdugum.sonraki;
       }
       while(yazdirdugum != ilk);
       return true;
    }

}
