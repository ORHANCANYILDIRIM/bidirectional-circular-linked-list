package bagliliste;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author MU$TA ORHAN
 */
public class dugum {            //düğüm yapısını oluşturuyor
    
    int deger;                  
    dugum sonraki;
    dugum önceki ;
    public dugum(int deger){
        this.deger=deger;
    }
            
}
