package bagliliste;


import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author MU$TA ORHAN
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan= new Scanner(System.in);
        
      int dugumdeger,sayi,islem=-1;
      
       baglicift dairesel=new baglicift();
       
      while(islem!=0){
          System.out.println(" 1.Basa ekle\n 2.sona ekle\n 3.dugumden once ekle\n 4. dugumden sonra ekle\n 5.Basdan cikar\n 6.sondan cikar\n 7.dugumden önce cikar\n 8.dugumden sonra cikar\n 9.arama\n 10.yazdır\n 0.cikis");
          islem=scan.nextInt();
          switch(islem){
              case 1:      // basa ekle
                  System.out.println("Sayi giriniz");
                  sayi=scan.nextInt();
                  dairesel.basaekle(sayi);
                  break;
              case 2:     //sona ekle
                  System.out.println("sayi griniz");
                  sayi=scan.nextInt();
                  dairesel.sonaekle(sayi);
                  break;
              case 3:     // dugumden önce ekle
                   System.out.println("sayi griniz");
                  sayi=scan.nextInt();
                   System.out.println("dugumu griniz");
                  dugumdeger=scan.nextInt();
                  if(!dairesel.dugumdenonceekle(sayi,dugumdeger))
                      System.out.println("dugum bulunamadı");
                  break;
                    
              case 4:    //dugumden sonra ekle
                  System.out.println("sayi griniz");
                  sayi=scan.nextInt();
                  System.out.println("dugumu griniz");
                  dugumdeger=scan.nextInt();
                  if(!dairesel.dugumdensonraekle(sayi,dugumdeger))
                      System.out.println("dugum bulunamadı");
                  
                  break;
              case 5:      // bastan çıkar
                  if(!dairesel.bastancikar())
                        System.out.println("liste bos!");
                  break;
              case 6:     // sondan cıkar
                  if(!dairesel.sondancikar())   
                         System.out.println("liste bos!");
                  
                  break;
              case 7:     //dugumden önce çıkar
                  System.out.println("dugumu griniz");
                  dugumdeger=scan.nextInt();
                  if(!dairesel.dugumdenoncecikar(dugumdeger))
                         System.out.println("dugum bulunamadı");

                  break;
                  
              case 8:     // dugumden sonra cıkar
                       System.out.println("dugumu griniz");
                  dugumdeger=scan.nextInt();
                  if(!dairesel.dugumdensonracikar(dugumdeger))
                         System.out.println("dugum bulunamadı");
                  break;
              case 9:    // arama  
                   System.out.println("dugumu griniz");
                  dugumdeger=scan.nextInt();
                  if(!dairesel.arama(dugumdeger)){
                      System.out.println("aradiginiz sayi yok");
                  }
                  break;
              case 10:     // yazdır
                  if(!dairesel.yazdir()){
                      System.out.println("hata liste bos");
                  }
                  break;
          }
      }
    }
}
